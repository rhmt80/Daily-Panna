import SwiftUI
import CoreData

struct ExpenseOverviewView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @FetchRequest(
        entity: ExpenseItem.entity(),
        sortDescriptors: [NSSortDescriptor(keyPath: \ExpenseItem.date, ascending: false)],
        animation: .default)
    private var expenses: FetchedResults<ExpenseItem>
    
    var body: some View {
        NavigationView {
            List {
                Section(header: Text("Total Expenses")) {
                    HStack {
                        Text("This Month")
                        Spacer()
                        Text("₹\(monthlyTotal)")
                    }
                    
                    HStack {
                        Text("This Week")
                        Spacer()
                        Text("₹\(weeklyTotal)")
                    }
                }
                
                Section(header: Text("By Category")) {
                    ForEach(categoryTotals, id: \.0) { category, total in
                        HStack {
                            Text(category)
                            Spacer()
                            Text("₹\(total)")
                        }
                    }
                }
            }
            .navigationTitle("Overview")
        }
    }
    
    private var monthlyTotal: String {
        let calendar = Calendar.current
        let startOfMonth = calendar.date(from: calendar.dateComponents([.year, .month], from: Date()))!
        
        return calculateTotal(from: startOfMonth)
    }
    
    private var weeklyTotal: String {
        let calendar = Calendar.current
        let startOfWeek = calendar.date(from: calendar.dateComponents([.yearForWeekOfYear, .weekOfYear], from: Date()))!
        
        return calculateTotal(from: startOfWeek)
    }
    
    private func calculateTotal(from date: Date) -> String {
        let filtered = expenses.filter { $0.date ?? Date() >= date }
        let total = filtered.reduce(0) { $0 + (Decimal(string: "\($1.amount)") ?? 0) }
        return formatAmount(total)
    }
    
    private var categoryTotals: [(String, String)] {
        var totals: [String: Decimal] = [:]
        
        for expense in expenses {
            let categoryName = expense.category?.name ?? "Uncategorized"
            let amount = Decimal(string: "\(expense.amount)") ?? 0
            totals[categoryName, default: 0] += amount
        }
        
        return totals.map { ($0.key, formatAmount($0.value)) }
            .sorted { $0.0 < $1.0 }
    }
    
    private func formatAmount(_ amount: Decimal) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        formatter.maximumFractionDigits = 2
        return formatter.string(from: amount as NSNumber) ?? "0"
    }
}
