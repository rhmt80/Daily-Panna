import SwiftUI

struct CategoryManagementView: View {
    @Environment(\.managedObjectContext) private var viewContext
        @FetchRequest(
            entity: CategoryItem.entity(),
            sortDescriptors: [NSSortDescriptor(keyPath: \CategoryItem.name, ascending: true)],
            animation: .default)
        private var categories: FetchedResults<CategoryItem>
    
    @State private var showingAddCategory = false
    @State private var newCategoryName = ""
    
    var body: some View {
        NavigationView {
            List {
                ForEach(categories, id: \.id) { category in
                    Text(category.name ?? "")
                }
                .onDelete(perform: deleteCategories)
            }
            .navigationTitle("Categories")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: { showingAddCategory = true }) {
                        Label("Add Category", systemImage: "plus")
                    }
                }
            }
            .alert("Add Category", isPresented: $showingAddCategory) {
                TextField("Category Name", text: $newCategoryName)
                Button("Cancel", role: .cancel) {}
                Button("Add") {
                    addCategory()
                }
            }
        }
    }
    
    private func addCategory() {
        withAnimation {
            let newCategory = CategoryItem(context: viewContext)
            newCategory.id = UUID()
            newCategory.name = newCategoryName
            newCategory.colorHex = "#\(String(format: "%06X", Int.random(in: 0..<0xFFFFFF)))"
            
            do {
                try viewContext.save()
                newCategoryName = ""
            } catch {
                let nsError = error as NSError
                fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
            }
        }
    }
    
    private func deleteCategories(offsets: IndexSet) {
        withAnimation {
            offsets.map { categories[$0] }.forEach(viewContext.delete)
            try? viewContext.save()
        }
    }
}
