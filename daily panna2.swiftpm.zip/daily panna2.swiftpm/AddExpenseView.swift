import SwiftUI

struct AddExpenseView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @Environment(\.presentationMode) var presentationMode
    
    @State private var amount: String = ""
    @State private var description: String = ""
    @State private var notes: String = ""
    @State private var date = Date()
    @State private var selectedCategory: CategoryItem?

    @FetchRequest(
        sortDescriptors: [NSSortDescriptor(keyPath: \CategoryItem.name, ascending: true)],
        animation: .default)
    private var categories: FetchedResults<CategoryItem>

    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Amount")) {
                    TextField("Amount (₹)", text: $amount)
                        .keyboardType(.decimalPad)
                }
                
                Section(header: Text("Details")) {
                    TextField("Description", text: $description)
                    TextField("Notes (optional)", text: $notes)
                    DatePicker("Date", selection: $date, displayedComponents: .date)
                }
                
                Section(header: Text("Category")) {
                    Picker("Category", selection: $selectedCategory) {
                        ForEach(categories, id: \.id) { category in
                            Text(category.name ?? "").tag(category as CategoryItem?)
                        }
                    }
                }
            }
            .navigationTitle("Add Expense")
            .navigationBarItems(
                leading: Button("Cancel") {
                    presentationMode.wrappedValue.dismiss()
                },
                trailing: Button("Save") {
                    saveExpense()
                }
            )
        }
    }
    
    private func saveExpense() {
        withAnimation {
            let newExpense = ExpenseItem(context: viewContext)
            newExpense.id = UUID()
            newExpense.amount = Double(truncating: NSDecimalNumber(string: amount))
            newExpense.desc = description
            newExpense.notes = notes
            newExpense.date = date
            newExpense.category = selectedCategory
            
            do {
                try viewContext.save()
                presentationMode.wrappedValue.dismiss()
            } catch {
                let nsError = error as NSError
                fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
            }
        }
    }
}
