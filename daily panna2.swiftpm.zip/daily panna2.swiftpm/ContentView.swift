import SwiftUI
import CoreData

struct ContentView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @State private var showingAddExpense = false
    @State private var selectedTab = 0
    
    var body: some View {
        TabView(selection: $selectedTab) {
            ExpenseListView()
                .tabItem {
                    Label("Expenses", systemImage: "list.bullet")
                }
                .tag(0)
            
            ExpenseOverviewView()
                .tabItem {
                    Label("Overview", systemImage: "chart.pie")
                }
                .tag(1)
            
            CategoryManagementView()
                .tabItem {
                    Label("Categories", systemImage: "folder")
                }
                .tag(2)
        }
    }
}
