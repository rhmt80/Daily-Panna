import Foundation
import CoreData

@objc(ExpenseItem)
public class ExpenseItem: NSManagedObject {
    @NSManaged public var id: UUID?
    @NSManaged public var amount: Double
    @NSManaged public var date: Date?
    @NSManaged public var desc: String?
    @NSManaged public var notes: String?
    @NSManaged public var category: CategoryItem?
}

@objc(CategoryItem)
public class CategoryItem: NSManagedObject {
    @NSManaged public var id: UUID?
    @NSManaged public var name: String?
    @NSManaged public var colorHex: String?
    @NSManaged public var expenses: NSSet?
}
