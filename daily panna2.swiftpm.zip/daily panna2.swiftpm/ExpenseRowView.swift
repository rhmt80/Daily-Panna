import SwiftUI

struct ExpenseRowView: View {
    let expense: ExpenseItem
    
    var body: some View {
        HStack {
            VStack(alignment: .leading) {
                Text(expense.desc ?? "")
                    .font(.headline)
                Text(expense.category?.name ?? "Uncategorized")
                    .font(.caption)
                    .foregroundColor(.gray)
            }
            
            Spacer()
            
            VStack(alignment: .trailing) {
                Text("₹\(String(format: "%.2f", expense.amount))")
                    .font(.headline)
                Text(expense.date?.formatted(date: .abbreviated, time: .omitted) ?? "")
                    .font(.caption)
                    .foregroundColor(.gray)
            }
        }
        .padding(.vertical, 4)
    }
}
