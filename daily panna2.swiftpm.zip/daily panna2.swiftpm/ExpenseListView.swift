import SwiftUI

struct ExpenseListView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @FetchRequest(
        entity: ExpenseItem.entity(),
        sortDescriptors: [NSSortDescriptor(keyPath: \ExpenseItem.date, ascending: false)],
        animation: .default)
    private var expenses: FetchedResults<ExpenseItem>
    
    @State private var showingAddExpense = false
    
    var body: some View {
        NavigationView {
            List {
                ForEach(expenses, id: \.id) { expense in
                    ExpenseRowView(expense: expense)
                }
                .onDelete(perform: deleteExpenses)
            }
            .navigationTitle("Expenses")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: { showingAddExpense = true }) {
                        Label("Add Expense", systemImage: "plus")
                    }
                }
            }
            .sheet(isPresented: $showingAddExpense) {
                AddExpenseView()
            }
        }
    }
    
    private func deleteExpenses(offsets: IndexSet) {
        withAnimation {
            offsets.map { expenses[$0] }.forEach(viewContext.delete)
            try? viewContext.save()
        }
    }
}
